#include <SFML/Graphics.hpp>
#include <iostream>

using namespace sf;
using namespace std;

int main(){
    RenderWindow window(VideoMode(500,500),"Pong",Style::None);
    window.setFramerateLimit(150);

    RectangleShape padd1(Vector2f(25,75));
    padd1.setPosition(5,212.5);
    RectangleShape padd2(Vector2f(25,75));
    padd2.setPosition(470,212.5);
    RectangleShape ball(Vector2f(10,10));
    ball.setPosition(245,rand() % 490);
    Vector2f ballDir(1,1); 

    int score[2] = {0,0};
    Font font;
    font.loadFromFile("C:/Windows/Fonts/Arial.ttf");
    Text scoreText;
    scoreText.setFont(font);
    scoreText.setString(string(to_string(score[0])) + " : " + string(to_string(score[1])));
    scoreText.setFillColor(Color::White);
    scoreText.setPosition(250,0);

    Text gameoverText;
    gameoverText.setFont(font);
    gameoverText.setFillColor(Color::White);
    gameoverText.setPosition(165,200);
    
    while(window.isOpen()){
        Event event;
        while (window.pollEvent(event))
        {
            if (event.type == Event::Closed){
                window.close();
            }
        }

        scoreText.setOrigin(scoreText.getLocalBounds().width / 2,0);

        if(Keyboard::isKeyPressed(Keyboard::Up)){
            padd2.move(0,-1);
        }
        if(Keyboard::isKeyPressed(Keyboard::Down)){
            padd2.move(0,1);
        }
        if(Keyboard::isKeyPressed(Keyboard::W)){
            padd1.move(0,-1);
        }
        if(Keyboard::isKeyPressed(Keyboard::S)){
            padd1.move(0,1);
        }
        if(Keyboard::isKeyPressed(Keyboard::BackSpace)){
            window.close();
        }

        if(ball.getPosition().x  - 10 < 0){
            score[1] += 1; 
            ball.setPosition(245,rand() % 490);
        }
        if(ball.getPosition().x > 500){
            score[0] += 1; 
            ball.setPosition(245,rand() % 490);
        }
        if(ball.getPosition().y > 500 - 10){
            ballDir.y = -1;
        }
        if(ball.getPosition().y < 0){
            ballDir.y = 1;
        }
        if(padd1.getGlobalBounds().intersects(ball.getGlobalBounds())){
            ballDir.x = 1;
        }
        if(padd2.getGlobalBounds().intersects(ball.getGlobalBounds())){
            ballDir.x = -1;
        }

        if(padd1.getPosition().y < 0){
            padd1.setPosition(5,0);
        }
        if(padd1.getPosition().y > 425){
            padd1.setPosition(5,425);
        }
        if(padd2.getPosition().y < 0){
            padd2.setPosition(470,0);
        }
        if(padd2.getPosition().y > 425){
            padd2.setPosition(470,425);
        }

        if(score[0] == 10){
            ball.setPosition(245,245);
            padd1.setPosition(5,212.5);
            padd2.setPosition(470,212.5);
            gameoverText.setString("Player 1 Wins!");
        }
        else if(score[1] == 10){
            ball.setPosition(245,245);
            padd1.setPosition(5,212.5);
            padd2.setPosition(470,212.5);
            gameoverText.setString("Player 2 Wins!");
        }

        ball.move(ballDir);
        window.clear();
        scoreText.setString(string(to_string(score[0])) + " : " + string(to_string(score[1])));
        window.draw(gameoverText);
        window.draw(scoreText);
        window.draw(padd1);
        window.draw(padd2);
        window.draw(ball);
        window.display();
    }

    return 0;
}