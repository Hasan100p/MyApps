#include <SFML/Graphics.hpp>
#include <iostream>

using namespace sf;
using namespace std;

int main(){
    RenderWindow window(VideoMode(500,500),"Game",Style::None);
    window.setFramerateLimit(20);

    vector<RectangleShape> player1 = {RectangleShape(Vector2f(10,10))};
    int player1dir[2] = {0,1};
    player1[0].setPosition(0,0);
    vector<RectangleShape> player2 = {RectangleShape(Vector2f(10,10))};
    int player2dir[2] = {0,-1};
    player2[0].setPosition(490,490);

    RectangleShape newRect(Vector2f(10,10));

    bool gameOver = false;
    Font font;
    font.loadFromFile("C:/Windows/Fonts/Arial.ttf");

    Text gameOverText;
    gameOverText.setFont(font);
    gameOverText.setFillColor(Color::Black);
    gameOverText.setPosition(250,250);

    while(window.isOpen()){
        Event ev;
        while(window.pollEvent(ev)){
            if(ev.type == Event::Closed) {window.close();}
        }

        if(Keyboard::isKeyPressed(Keyboard::BackSpace)) {window.close();}

        //* Player1 Controls
        if(Keyboard::isKeyPressed(Keyboard::W) && player1dir[1] != 1){player1dir[0] = 0; player1dir[1] = -1;}
        if(Keyboard::isKeyPressed(Keyboard::A) && player1dir[0] != 1){player1dir[0] = -1; player1dir[1] = 0;}
        if(Keyboard::isKeyPressed(Keyboard::S) && player1dir[1] != -1){player1dir[0] = 0; player1dir[1] = 1;}
        if(Keyboard::isKeyPressed(Keyboard::D) && player1dir[0] != -1){player1dir[0] = 1; player1dir[1] = 0;}

        //* Player2 Controls
        if(Keyboard::isKeyPressed(Keyboard::Up) && player2dir[1] != 1){player2dir[0] = 0; player2dir[1] = -1;}
        if(Keyboard::isKeyPressed(Keyboard::Left) && player2dir[0] != 1){player2dir[0] = -1; player2dir[1] = 0;}
        if(Keyboard::isKeyPressed(Keyboard::Down) && player2dir[1] != -1){player2dir[0] = 0; player2dir[1] = 1;}
        if(Keyboard::isKeyPressed(Keyboard::Right) && player2dir[0] != -1){player2dir[0] = 1; player2dir[1] = 0;}

        window.clear(Color::White);

        if(!gameOver){
            //* Player1 movement
            newRect.setPosition(player1dir[0] * 10 + player1[0].getPosition().x,player1dir[1] * 10 + player1[0].getPosition().y);
            player1.insert(player1.begin(),newRect);

            //* Player2 movement
            newRect.setPosition(player2dir[0] * 10 + player2[0].getPosition().x,player2dir[1] * 10 + player2[0].getPosition().y);
            player2.insert(player2.begin(),newRect);
        }

        //* Player1 Drawing
        for(int i=0;i<player1.size();i++) {
            if(i == 0){
                player1[0].setFillColor(Color(0, 225, 255));
            } else {
                player1[i].setFillColor(Color(0, 81, 255));
                if(player1[i].getPosition() == player2[0].getPosition()){
                    gameOver = true;gameOverText.setString("Player1 Wins");
                }
                if(player1[i].getPosition().x == -10 ||
                  player1[i].getPosition().y == -10 ||
                  player1[i].getPosition().x == 500 ||
                  player1[i].getPosition().y == 500 ||
                  player1[0].getPosition() == player1[i].getPosition()){gameOver = true;gameOverText.setString("Player2 Wins");}
            }

            window.draw(player1[i]);
        }

        //* Player2 Drawing
        for(int i=0;i<player2.size();i++) {
            if(i == 0){
                player2[0].setFillColor(Color::Red);
            } else {
                player2[i].setFillColor(Color(165,0,0));
                if(player2[i].getPosition() == player1[0].getPosition()){
                    gameOver = true;gameOverText.setString("Player2 Wins");
                }
                if(player2[i].getPosition().x == -10 ||
                  player2[i].getPosition().y == -10 ||
                  player2[i].getPosition().x == 500 ||
                  player2[i].getPosition().y == 500 ||
                  player2[0].getPosition() == player2[i].getPosition()){gameOver = true;gameOverText.setString("Player1 Wins");}
            }

            window.draw(player2[i]);
        }

        gameOverText.setOrigin(gameOverText.getLocalBounds().left + gameOverText.getLocalBounds().width/2,gameOverText.getLocalBounds().top + gameOverText.getLocalBounds().height/2);
        window.draw(gameOverText);
        window.display();
    }
    return 0;
}