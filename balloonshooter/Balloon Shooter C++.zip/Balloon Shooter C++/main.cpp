#include <SFML/Graphics.hpp>
#include <iostream>

using namespace std;
using namespace sf;

int main(){
    RenderWindow window(VideoMode(500,500), "Game", Style::None);
    window.setMouseCursorVisible(false);
    window.setFramerateLimit(100);

    Texture cursorTexture;
    cursorTexture.loadFromFile("target.png");
    Sprite cursor;
    cursor.setTexture(cursorTexture);
    cursor.setOrigin(Vector2f(25,25));
    cursor.scale(0.09765625,0.09765625);

    int score = 0;
    Texture balloonTexture;
    balloonTexture.loadFromFile("balloon.png");
    vector<Sprite> balloons;
    Sprite balloon;
    balloon.setTexture(balloonTexture);
    balloon.setOrigin(25,25);
    balloon.setScale(0.09765625,0.09765625);
    Clock clock;
    float balloonCooldown = clock.getElapsedTime().asSeconds() + 1;

    Font font;
    font.loadFromFile("C:/Windows/Fonts/Arial.ttf");
    Text scoreText;
    scoreText.setFont(font);
    scoreText.setPosition(0,0);

    bool isReload = true;

    while(window.isOpen()){
        Event e;
        while(window.pollEvent(e)){
            if(e.type == Event::Closed){
                window.close();
            }
            if(e.type == Event::MouseButtonReleased && e.mouseButton.button == Mouse::Left){
                isReload = true;
            }
        }
        if(Keyboard::isKeyPressed(Keyboard::BackSpace)){
            window.close();
        }
        if(balloonCooldown < clock.getElapsedTime().asSeconds()){
            balloon.setPosition(rand() % 450 + 0,-50);
            balloons.push_back(balloon);
            if(2-(0.1*score) > 0.25){
                balloonCooldown = clock.getElapsedTime().asSeconds() + 2-(0.1 * score);
            } else {
                balloonCooldown = clock.getElapsedTime().asSeconds() + 0.25;
            }
        }
        
        window.clear(Color(0,155,255));
        cursor.setPosition(Vector2f(Mouse::getPosition(window)));
        window.draw(cursor);
        for(int i=0; i<balloons.size(); i++) {
            balloons[i].move(0,1+(0.075*score));
            window.draw(balloons[i]);

            if(balloons[i].getPosition().y > 500){
                balloons.erase(balloons.begin());
                score -= 1;
            }
            if(Mouse::isButtonPressed(Mouse::Left) && cursor.getGlobalBounds().intersects(balloons[i].getGlobalBounds()) && isReload){
                balloons.erase(balloons.begin() + i);
                score += 1;
                isReload = false;
            }
        }
        scoreText.setString("Score - " + to_string(score));
        window.draw(scoreText);
        window.display();
    }
    return 0;
}