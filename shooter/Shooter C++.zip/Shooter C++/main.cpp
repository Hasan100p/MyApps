#include <iostream>
#include <stdlib.h>
#include <SFML/Graphics.hpp>
#include <chrono>
#include <math.h>

using namespace sf;

int main(){

    //* Create window
    RenderWindow window(VideoMode(500,500), "Game", Style::None);
    window.setFramerateLimit(100);

    //* Load textures
    Texture rectTexture;
    rectTexture.loadFromFile("./images/player-bullet-enemy.png");

    //* Create player
    Sprite player;
    player.setTexture(rectTexture);
    player.setColor(Color(222, 141, 0));
    player.setTextureRect(IntRect(37,37,37,37));
    player.setOrigin(18,18);
    player.setPosition(400,400);
    
    //* Create enemies
    struct enemy {
        Sprite body;
        float velocity;
        float power;
    };
    std::vector<enemy> enemies;
    time_t enemySpawnTime = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());

    //* Create bullets
    struct bullet {
        Sprite body;
        Vector2f bulletVel;
    };
    std::vector<bullet> bullets;
    float bulletVel = 0.0f;
    float bulletCooldown = 0.5f;
    time_t bulletFireTime = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());

    //* Create score
    int score = 0;
    Font font;
    font.loadFromFile("C:/Windows/Fonts/Arial.ttf");
    Text scoreText;
    scoreText.setFont(font);
    scoreText.setCharacterSize(24);
    scoreText.setFillColor(Color::Black);

    //* PowerUps
    int canPassablePowerUp = 5;
    Text powerText;
    powerText.setFont(font);
    powerText.setCharacterSize(16);
    powerText.setFillColor(Color(66, 245, 117));
    powerText.setString("Power Ups\n[1] Bullet Reload Speed\n[2] Bullet Speed\n");
    powerText.setPosition(0,50);

    //* Main loop
    while(window.isOpen()){

        Event event;
        while(window.pollEvent(event)){

            //* Close window
            switch(event.type){
                case Event::Closed:
                    window.close();
                    break;
            }
        }

        //* Move player
        if(Keyboard::isKeyPressed(Keyboard::W) || Keyboard::isKeyPressed(Keyboard::Up)){
            player.move(0.0f,-1.5);
        }
        if(Keyboard::isKeyPressed(Keyboard::S) || Keyboard::isKeyPressed(Keyboard::Down)){
            player.move(0.0f,1.5);
        }
        if(Keyboard::isKeyPressed(Keyboard::A) || Keyboard::isKeyPressed(Keyboard::Left)){
            player.move(-1.5,0.0f);
        }
        if(Keyboard::isKeyPressed(Keyboard::D) || Keyboard::isKeyPressed(Keyboard::Right)){
            player.move(1.5,0.0f);
        }
        if(Mouse::isButtonPressed(Mouse::Left) && std::chrono::system_clock::to_time_t(std::chrono::system_clock::now()) - bulletFireTime >= bulletCooldown){
            bullet newbullet;
            newbullet.body.setColor(Color(255,0,0));
            newbullet.body.setTexture(rectTexture);
            newbullet.body.setTextureRect(IntRect(23,18,23,18));
            newbullet.body.setOrigin(9,11);
            newbullet.body.setPosition(player.getPosition());
            newbullet.body.setRotation(player.getRotation());

            float distX = (Mouse::getPosition(window).x - player.getPosition().x)/100;
            distX += distX * bulletVel;
            float distY = (Mouse::getPosition(window).y - player.getPosition().y)/100;
            distY += distY * bulletVel;

            newbullet.bulletVel = Vector2f(distX, distY);
            bullets.push_back(newbullet);
            bulletFireTime = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
        }
        if(Keyboard::isKeyPressed(Keyboard::BackSpace)){
            window.close();
        }
        window.clear(Color(255,255,255));
        
        if(score >= canPassablePowerUp){
            window.draw(powerText);
            if(Keyboard::isKeyPressed(Keyboard::Num1) || Keyboard::isKeyPressed(Keyboard::Numpad1)){
                bulletCooldown = bulletCooldown - (bulletCooldown / 1.0001);
                canPassablePowerUp += 5; 
                std::cout << "BulletCooldown: " << bulletCooldown << "\n";
            }
            if(Keyboard::isKeyPressed(Keyboard::Num2) || Keyboard::isKeyPressed(Keyboard::Numpad2)){
                bulletVel += 1;
                canPassablePowerUp += 5;
                std::cout << "BulletVel: " << bulletVel << "\n";
            }
        }

        //* Player and enemy collision
        for(int i=0;i<enemies.size();i++){
            if(player.getGlobalBounds().intersects(enemies[i].body.getGlobalBounds())){
                player.setColor(Color(196, 255, 14));
                score -= enemies[i].power;
                enemies.erase(enemies.begin() + i);
                break;
            } else {
                player.setColor(Color(222, 141, 0));
            }
        }

        //* Spawn enemies
        if(std::chrono::system_clock::to_time_t(std::chrono::system_clock::now()) - enemySpawnTime >= 1){
            enemy newenemy;
            newenemy.body.setTexture(rectTexture);
            newenemy.body.setTextureRect(IntRect(25,25,25,25));
            newenemy.body.setColor(Color(rand() % 235 + 165,rand() % 235 + 165,rand() % 235 + 165));
            int pos = rand() % 4; 
            if(pos == 0){
                newenemy.body.setPosition(rand() % 775,-50); 
            } else if(pos == 1){
                newenemy.body.setPosition(rand() % 775,850); 
            } else if(pos == 2){
                newenemy.body.setPosition(-50,rand() % 775);
            } else if(pos == 3){
                newenemy.body.setPosition(850,rand() % 775);
            }
            newenemy.velocity = 1+(score * 0.025);
            newenemy.power = 1+(score * 0.025);

            enemies.push_back(newenemy);
            enemySpawnTime = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
        }

        //* Run enemies
        for(int i=0;i<enemies.size();i++){

            //* Draw enemies
            window.draw(enemies[i].body);

            //* Enemy Enemy collision
            for(int j=0; j<enemies.size(); j++){
                if(enemies[j].body.getPosition().x != enemies[i].body.getPosition().x && enemies[j].body.getPosition().y != enemies[i].body.getPosition().y && enemies[j].body.getGlobalBounds().intersects(enemies[i].body.getGlobalBounds())){
                    if(enemies[j].body.getPosition().x > enemies[i].body.getPosition().x){
                        enemies[i].body.move(-7.5f,0.0f);
                    }
                    if(enemies[j].body.getPosition().x < enemies[i].body.getPosition().x){
                        enemies[i].body.move(7.5f,0.0f);
                    }
                    if(enemies[j].body.getPosition().y > enemies[i].body.getPosition().y){
                        enemies[i].body.move(0.0f,-7.5f);
                    }
                    if(enemies[j].body.getPosition().y < enemies[i].body.getPosition().y){
                        enemies[i].body.move(0.0f,7.5f);
                    }
                }
            }

            //* Move enemies
            if(enemies[i].body.getPosition().x < player.getPosition().x){
                enemies[i].body.move(enemies[i].velocity,0.0f);
            }
            if(enemies[i].body.getPosition().x > player.getPosition().x){
                enemies[i].body.move(-enemies[i].velocity,0.0f);
            }
            if(enemies[i].body.getPosition().y < player.getPosition().y){
                enemies[i].body.move(0.0f,enemies[i].velocity);
            }
            if(enemies[i].body.getPosition().y > player.getPosition().y){
                enemies[i].body.move(0.0f,-enemies[i].velocity);
            }
        }
        //* Run bullets
        for(int i=0; i<bullets.size(); i++){
            window.draw(bullets[i].body);

            //* Move bullets
            bullets[i].body.move(bullets[i].bulletVel.x + (bullets[i].bulletVel.x * bulletVel), bullets[i].bulletVel.y + (bullets[i].bulletVel.x * bulletVel));

            //* Remove bullets
            if(bullets[i].body.getPosition().x < -23 || bullets[i].body.getPosition().y < - -18 || bullets[i].body.getPosition().x > 800 || bullets[i].body.getPosition().y > 800){
                bullets.erase(bullets.begin() + i);
            }

            //* Bullet and enemy collision
            for(int k=0;k<enemies.size();k++){
                if(bullets[i].body.getGlobalBounds().intersects(enemies[k].body.getGlobalBounds())){
                    score += 1;
                    bullets.erase(bullets.begin() + i);
   
                    enemies.erase(enemies.begin() + k);   
                }
            }
        }

        //* Turn to mouse
        float a = sf::Mouse::getPosition(window).x - player.getPosition().x;
        float b = sf::Mouse::getPosition(window).y - player.getPosition().y;
        player.setRotation(-atan2( a , b) * 180 / 3.14);

        scoreText.setString(std::string("Score - '") + std::to_string(score) + std::string("'"));
        window.draw(scoreText);
        window.draw(player);
        window.display();
    }
    return 0;
}