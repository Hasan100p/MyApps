#include <SFML/Graphics.hpp>
#include <iostream>

using namespace std;
using namespace sf;

int main(){
    RenderWindow window(VideoMode(500,500),"Game",Style::None);
    window.setFramerateLimit(100);
    RectangleShape bird(Vector2f(25,25));
    bird.setPosition(235.5f,235.5f);
    bird.setFillColor(Color::Yellow);

    Font font;
    font.loadFromFile("C:/Windows/Fonts/Arial.ttf");

    int score = 3;
    Text scoreText;
    scoreText.setFont(font);
    scoreText.setFillColor(Color::White);
    scoreText.setPosition(0,0);

    vector<RectangleShape> pipes; //* Spawn cooldown  = 1/score*3 & Pipe speed = score/3
    RectangleShape pipe;
    Clock clock;
    float time = clock.getElapsedTime().asSeconds() + (1/score+3);
    bool isScored = false;

    float startopenness = 0;

    while(window.isOpen()){
        Event ev;
        while(window.pollEvent(ev)){
            if(ev.type == Event::Closed){
                window.close();
            }
        }
        bird.move(0,2);
        if(Keyboard::isKeyPressed(Keyboard::BackSpace)){
            window.close();
        }
        if(Keyboard::isKeyPressed(Keyboard::Space) || Keyboard::isKeyPressed(Keyboard::Up)){
            bird.move(0,-4);
        }

        if(time < clock.getElapsedTime().asSeconds()){
            startopenness = rand() % 420 + 0;
            pipe.setSize(Vector2f(25,startopenness));
            pipe.setPosition(500,0);
            pipe.setFillColor(Color(0,127,0));
            pipes.push_back(pipe);
            pipe.setSize(Vector2f(25,500-startopenness-80));
            pipe.setPosition(500,startopenness+80);
            pipe.setFillColor(Color(0,127,0));
            pipes.push_back(pipe);
            time = clock.getElapsedTime().asSeconds() + (1/score+3);
        } 

        window.clear(Color(0, 155, 255));
        scoreText.setString("Score - " + to_string(score - 3));
        window.draw(scoreText);
        for(int i=0;i<pipes.size();i++){
            
            pipes[i].move(-1*(score/3),0);
            if(pipes[i].getPosition().x + 25 < 0){
                pipes.erase(pipes.begin());
            }
            window.draw(pipes[i]);
        }
        for(int i=0;i<pipes.size();i++){
            if(pipes[i].getGlobalBounds().intersects(bird.getGlobalBounds())){
                score = 3;
                time = clock.getElapsedTime().asSeconds() + (1/score+3);
                isScored = false;
                startopenness = 0;
                pipes = {};
                bird.setPosition(235.5f,235.5f);
                break;
            }
            else if(bird.getPosition().x > pipes[i].getPosition().x && bird.getPosition().x < pipes[i].getPosition().x + 25 && !isScored){
                score += 1;
                isScored = true;
                break;
            }
            else if(bird.getPosition().x > pipes[i].getPosition().x + 25 && isScored){
                isScored=false;
                break;
            }
        }
        if(bird.getPosition().y >= 500 || bird.getPosition().y + 25 <= 0){
            score = 3;
            time = clock.getElapsedTime().asSeconds() + (1/score+3);
            isScored = false;
            startopenness = 0;
            pipes = {};
            bird.setPosition(235.5f,235.5f);
        }

        window.draw(bird);
        window.display();
    }

    return 0;
}