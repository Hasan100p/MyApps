#include <SFML/Graphics.hpp>
#include <iostream>

using namespace std;
using namespace sf;

int main(){
    RenderWindow window(VideoMode(500,500),"Game",Style::None);

    bool turnIsX = true;
    vector<string> game = {" "," "," ",
                           " "," "," ",
                           " "," "," "};
    Font font;
    font.loadFromFile("C:/Windows/Fonts/Arial.ttf");
    
    Text text;
    text.setFont(font);

    RectangleShape Line(Vector2f(500,2.5f));
    Line.setFillColor(Color::Black);

    while(window.isOpen()){
        text.setOrigin(text.getLocalBounds().left + text.getLocalBounds().width/2.0f,text.getLocalBounds().top  + text.getLocalBounds().height/2.0f);

        Event ev;
        while(window.pollEvent(ev)){
            if(ev.type == Event::Closed){
                window.close();
            }
        }
    
        if(Keyboard::isKeyPressed(Keyboard::BackSpace)){
            window.close();
        }
        window.clear(Color::White);

        if(Mouse::isButtonPressed(Mouse::Left) && Mouse::getPosition(window).x < 500/3 && Mouse::getPosition(window).y < 500/3 && game[0] == " ") {
            if(turnIsX){
                game[0] = "X";
                turnIsX = false;
            }
            else if(!turnIsX){
                game[0] = "O";
                turnIsX = true;
            }
        }
        if(Mouse::isButtonPressed(Mouse::Left) && Mouse::getPosition(window).x > 500/3 && Mouse::getPosition(window).x < 500-500/3 && Mouse::getPosition(window).y < 500/3 && game[1] == " ") {
            if(turnIsX){
                game[1] = "X";
                turnIsX = false;
            }
            else if(!turnIsX){
                game[1] = "O";
                turnIsX = true;
            }
        }
        if(Mouse::isButtonPressed(Mouse::Left) && Mouse::getPosition(window).x > 500-500/3 && Mouse::getPosition(window).y < 500/3 && game[2] == " ") {
            if(turnIsX){
                game[2] = "X";
                turnIsX = false;
            }
            else if(!turnIsX){
                game[2] = "O";
                turnIsX = true;
            }
        }

        if(Mouse::isButtonPressed(Mouse::Left) && Mouse::getPosition(window).x < 500/3 && Mouse::getPosition(window).y > 500/3 && Mouse::getPosition(window).y < 500-500/3 && game[3] == " ") {
            if(turnIsX){
                game[3] = "X";
                turnIsX = false;
            }
            else if(!turnIsX){
                game[3] = "O";
                turnIsX = true;
            }
        }
        if(Mouse::isButtonPressed(Mouse::Left) && Mouse::getPosition(window).x > 500/3 && Mouse::getPosition(window).x < 500-500/3 && Mouse::getPosition(window).y > 500/3 && Mouse::getPosition(window).y < 500-500/3 && game[4] == " ") {
            if(turnIsX){
                game[4] = "X";
                turnIsX = false;
            }
            else if(!turnIsX){
                game[4] = "O";
                turnIsX = true;
            }
        }
        if(Mouse::isButtonPressed(Mouse::Left) && Mouse::getPosition(window).x > 500-500/3 && Mouse::getPosition(window).y > 500/3 && Mouse::getPosition(window).y < 500-500/3 && game[5] == " ") {
            if(turnIsX){
                game[5] = "X";
                turnIsX = false;
            }
            else if(!turnIsX){
                game[5] = "O";
                turnIsX = true;
            }
        }

        if(Mouse::isButtonPressed(Mouse::Left) && Mouse::getPosition(window).x < 500/3 && Mouse::getPosition(window).y > 500-500/3 && game[6] == " ") {
            if(turnIsX){
                game[6] = "X";
                turnIsX = false;
            }
            else if(!turnIsX){
                game[6] = "O";
                turnIsX = true;
            }
        }
        if(Mouse::isButtonPressed(Mouse::Left) && Mouse::getPosition(window).x > 500/3 && Mouse::getPosition(window).x < 500-500/3 && Mouse::getPosition(window).y > 500-500/3 && game[7] == " ") {
            if(turnIsX){
                game[7] = "X";
                turnIsX = false;
            }
            else if(!turnIsX){
                game[7] = "O";
                turnIsX = true;
            }
        }
        if(Mouse::isButtonPressed(Mouse::Left) && Mouse::getPosition(window).x > 500-500/3 && Mouse::getPosition(window).y > 500-500/3 && game[8] == " ") {
            if(turnIsX){
                game[8] = "X";
                turnIsX = false;
            }
            else if(!turnIsX){
                game[8] = "O";
                turnIsX = true;
            }
        }
        
        text.setString(game[0]);
        text.setOrigin(text.getLocalBounds().left + text.getLocalBounds().width/2.0f,text.getLocalBounds().top  + text.getLocalBounds().height/2.0f);
        text.setPosition(500/3/2,500/3/2);
        text.setFillColor(Color(100,100,100));
        window.draw(text);

        text.setString(game[1]);
        text.setOrigin(text.getLocalBounds().left + text.getLocalBounds().width/2.0f,text.getLocalBounds().top  + text.getLocalBounds().height/2.0f);
        text.setPosition((500-500/3)-(500/3/2),500/3/2);
        text.setFillColor(Color(100,100,100));
        window.draw(text);

        text.setString(game[2]);
        text.setOrigin(text.getLocalBounds().left + text.getLocalBounds().width/2.0f,text.getLocalBounds().top  + text.getLocalBounds().height/2.0f);
        text.setPosition((500)-(500/3/2),500/3/2);
        text.setFillColor(Color(100,100,100));
        window.draw(text);

        text.setString(game[3]);
        text.setOrigin(text.getLocalBounds().left + text.getLocalBounds().width/2.0f,text.getLocalBounds().top  + text.getLocalBounds().height/2.0f);
        text.setPosition(500/3/2,(500-500/3)-(500/3/2));
        text.setFillColor(Color(100,100,100));
        window.draw(text);

        text.setString(game[4]);
        text.setOrigin(text.getLocalBounds().left + text.getLocalBounds().width/2.0f,text.getLocalBounds().top  + text.getLocalBounds().height/2.0f);
        text.setPosition((500-500/3)-(500/3/2),(500-500/3)-(500/3/2));
        text.setFillColor(Color(100,100,100));
        window.draw(text);

        text.setString(game[5]);
        text.setOrigin(text.getLocalBounds().left + text.getLocalBounds().width/2.0f,text.getLocalBounds().top  + text.getLocalBounds().height/2.0f);
        text.setPosition((500)-(500/3/2),(500-500/3)-(500/3/2));
        text.setFillColor(Color(100,100,100));
        window.draw(text);

        text.setString(game[6]);
        text.setOrigin(text.getLocalBounds().left + text.getLocalBounds().width/2.0f,text.getLocalBounds().top  + text.getLocalBounds().height/2.0f);
        text.setPosition(500/3/2,(500)-(500/3/2));
        text.setFillColor(Color(100,100,100));
        window.draw(text);

        text.setString(game[7]);
        text.setOrigin(text.getLocalBounds().left + text.getLocalBounds().width/2.0f,text.getLocalBounds().top  + text.getLocalBounds().height/2.0f);
        text.setPosition((500-500/3)-(500/3/2),(500)-(500/3/2));
        text.setFillColor(Color(100,100,100));
        window.draw(text);

        text.setString(game[8]);
        text.setOrigin(text.getLocalBounds().left + text.getLocalBounds().width/2.0f,text.getLocalBounds().top  + text.getLocalBounds().height/2.0f);
        text.setPosition((500)-(500/3/2),(500)-(500/3/2));
        text.setFillColor(Color(100,100,100));
        window.draw(text);

        Line.setRotation(0);
        Line.setPosition(Vector2f(0,500/3));
        window.draw(Line);
        Line.setPosition(Vector2f(0,500-500/3));
        window.draw(Line);
        Line.setRotation(90);
        Line.setPosition(Vector2f(500/3,0));
        window.draw(Line);
        Line.setPosition(Vector2f(500-500/3,0));
        window.draw(Line);

        //* O WINS!
        if((game[0] == "O" && game[1] == "O" && game[2] == "O") || (game[3] == "O" && game[4] == "O" && game[5] == "O") || (game[6] == "O" && game[7] == "O" && game[8] == "O") || (game[0] == "O" && game[3] == "O" && game[6] == "O") || (game[1] == "O" && game[4] == "O" && game[7] == "O") || (game[2] == "O" && game[5] == "O" && game[8] == "O") || (game[2] == "O" && game[4] == "O" && game[6] == "O") || (game[0] == "O" && game[4] == "O" && game[8] == "O")){
            text.setString("O WINS!!!");
            text.setFillColor(Color::Black);
            text.setOrigin(text.getLocalBounds().left + text.getLocalBounds().width/2.0f,text.getLocalBounds().top  + text.getLocalBounds().height/2.0f);
            text.setPosition(250,250);
            window.draw(text);
        }

        //* X WINS!
        if((game[0] == "X" && game[1] == "X" && game[2] == "X") || (game[3] == "X" && game[4] == "X" && game[5] == "X") || (game[6] == "X" && game[7] == "X" && game[8] == "X") || (game[0] == "X" && game[3] == "X" && game[6] == "X") || (game[1] == "X" && game[4] == "X" && game[7] == "X") || (game[2] == "X" && game[5] == "X" && game[8] == "X") || (game[2] == "X" && game[4] == "X" && game[6] == "X") || (game[0] == "X" && game[4] == "X" && game[8] == "X")){
            text.setString("X WINS!!!");
            text.setFillColor(Color::Black);
            text.setOrigin(text.getLocalBounds().left + text.getLocalBounds().width/2.0f,text.getLocalBounds().top  + text.getLocalBounds().height/2.0f);
            text.setPosition(250,250);
            window.draw(text);
        }

        //* TIE!
        if(!(game[0] == " ") && !(game[1] == " ") && !(game[2] == " ") && !(game[3] == " ") && !(game[4] == " ") && !(game[5] == " ") && !(game[6] == " ") && !(game[7] == " ") && !(game[8] == " ")){
            text.setString("TIE");
            text.setFillColor(Color::Black);
            text.setOrigin(text.getLocalBounds().left + text.getLocalBounds().width/2.0f,text.getLocalBounds().top  + text.getLocalBounds().height/2.0f);
            text.setPosition(250,250);
            window.draw(text); 
        }

        window.display();
    }

    return 0;
}