#include <SFML/Graphics.hpp>
#include <iostream>
#include <math.h>

using namespace std;
using namespace sf;

int main(){
    RenderWindow window(VideoMode(500,500),"Game",Style::None);
    int frameLimit = 5;

    RectangleShape apple(Vector2f(20,20));
    apple.setFillColor(Color::Red);
    apple.setPosition((rand() % 25 + 0)*20,(rand() % 25 + 0)*20);

    vector<RectangleShape> snake;
    RectangleShape head(Vector2f(20,20));
    head.setFillColor(Color(0,255,0));
    snake.push_back(head);
    int dir[2] = {20,0};

    int score = 0;
    Font font;
    font.loadFromFile("C:/Windows/Fonts/Arial.ttf");
    Text scoreText;
    scoreText.setFont(font);
    scoreText.setFillColor(Color::Black);
    scoreText.setPosition(0,0);
    scoreText.setScale(0.75f,0.75f);

    bool gameOver = false;
    Text gameOverText;
    gameOverText.setFont(font);
    gameOverText.setFillColor(Color::Black);
    gameOverText.setString("Game Over");

    while(window.isOpen()){

        window.setFramerateLimit(floor(frameLimit));

        Event event;
        while(window.pollEvent(event)){
            if(event.type == Event::Closed){
                window.close();
            }
        }
    
        if(Keyboard::isKeyPressed(Keyboard::BackSpace)) window.close();
        if((Keyboard::isKeyPressed(Keyboard::W) || Keyboard::isKeyPressed(Keyboard::Up)) && !(gameOver)){ dir[0] = 0; dir[1] = -20;}
        if((Keyboard::isKeyPressed(Keyboard::S) || Keyboard::isKeyPressed(Keyboard::Down)) && !(gameOver)){ dir[0] = 0; dir[1] = 20;}
        if((Keyboard::isKeyPressed(Keyboard::A) || Keyboard::isKeyPressed(Keyboard::Left)) && !(gameOver)){ dir[0] = -20; dir[1] = 0;}
        if((Keyboard::isKeyPressed(Keyboard::D) || Keyboard::isKeyPressed(Keyboard::Right)) && !(gameOver)){ dir[0] = 20; dir[1] = 0;}

        if(snake[0].getGlobalBounds().intersects(apple.getGlobalBounds())){
            score += 1;
            frameLimit += 0.8;
            apple.setPosition((rand() % 25 + 0)*20,(rand() % 25 + 0)*20);
            RectangleShape sec(Vector2f(20,20));
            sec.setFillColor(Color(0,255,0));
            sec.setPosition(snake[snake.size() - 1].getPosition().x +dir[0],snake[snake.size() - 1].getPosition().y +dir[1]);
            snake.push_back(sec);
        }

        if(!gameOver){
                snake.pop_back();
                RectangleShape head(Vector2f(20,20));
                head.setFillColor(Color(0,255,0));
                head.setPosition(snake[0].getPosition().x + dir[0],snake[0].getPosition().y + dir[1]);
                snake.insert(snake.begin(),head);
        }
        
        window.clear(Color::White);
        for(int i=0; i<snake.size(); i++){
            if(i > 0){
                snake[i].setFillColor(Color(0,255,0));
            } else snake[0].setFillColor(Color(255,165,0));
            window.draw(snake[i]);
        }

        for(int i=1; i<snake.size(); i++){
            if(snake[0].getPosition() == snake[i].getPosition()){
                gameOver = true;
                break;
            }
        }
        if(snake[0].getPosition().x == 500 || snake[0].getPosition().x == -20 || snake[0].getPosition().y == 500 || snake[0].getPosition().y == -20){
            gameOver = true;
        }

        if(gameOver){
            gameOverText.setOrigin(gameOverText.getLocalBounds().width / 2,gameOverText.getLocalBounds().height / 2);
            gameOverText.setPosition(250,250);
            window.draw(gameOverText);
        }
        window.draw(apple);
        scoreText.setString(string("Score - ") + string(to_string(score)));
        window.draw(scoreText);
        window.display();
    }

    return 0;
}